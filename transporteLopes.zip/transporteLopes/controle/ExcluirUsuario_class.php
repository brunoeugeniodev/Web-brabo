<?php
include_once("modelo/UsuarioDAO_class.php");

class ExcluirUsuario{

	public function __construct(){
		if (isset($_GET["conf"])){
			if ($_GET["conf"] == "sim"){
				//enviar é o botão de submit

				$dao = new UsuarioDAO();
				$u = new Usuario(); //a diferença é que aqui a variável auxiliar tem o formato do veiculo
				$u = $dao->exibir($_GET["idUsuario"]); //encapsulando o id dentro de um obj Veiculo
				$dao->excluir($u);
				$status = "Usuario " . $u->getIdUsuario() . "-" . $u->getEmail() . " " . $u->getCpf() . " " . $u->getNomeCompleto() .  $u->getSenha() . " EXCLUIDO com sucesso.";

				$lista = $dao->listar();
				include_once("visao/listaUsuario.php");
				//para o funcionamento da visão da Listagem de veiculos
			}
		} else {
			//encaminhar para a página de confirmação de exclusão

			$dao = new VeiculoDAO();
			$u = $dao->exibir($_GET["idUsuario"]);

			include_once("visao/pagAutorizaExcluir.php");
		}
	}
}
