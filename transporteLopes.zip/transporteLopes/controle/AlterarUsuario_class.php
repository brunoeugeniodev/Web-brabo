<?php
include_once("modelo/UsuarioDAO_class.php");

class AlterarUsuario{
	
	public function __construct(){
		if (isset($_POST["enviar"])){
			//enviar é o botão de submit

			$u = new Usuario();
            $u->setIdUsuario($_POST["idUsuario"]);
			$u->setEmail($_POST["email"]);
			$u->setCpf($_POST["cpf"]);
			$u->setNomeCompleto($_POST["nomeCompleto"]);
			$u->setSenha($_POST["senha"]); //o id é fornecido por um campo hidden

			$dao = new UsuarioDAO();
			$dao->alterar($u);

			$status = "Usuario " . $u->getIdUsuario() . "-" . $u->getEmail() . " " . $u->getCpf() . " " . $u->getNomeCompleto() .  $u->getSenha() . " ALTERADO com sucesso.";

			$lista = $dao->listar();
			include_once("visao/listaUsuario.php");
			//para o funcionamento da visão da Listagem de veiculos
		} else {
			//se entrar no else significa que nenhum formulário foi enviado, ou seja, a pessoa ainda não cadastrou o veiculo

			//ALTERAR -> pegar os dados do veiculo pelo $_GET["id"]

			$dao = new UsuarioDAO();
			$v = $dao->exibir($_GET["idUsuario"]); //única diferença é o $cont nessa linha no lugar do $c

			include_once("visao/formAlteraUsuario.php");
		}
	}
}
