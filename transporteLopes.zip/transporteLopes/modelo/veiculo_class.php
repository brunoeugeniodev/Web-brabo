<?php
class Veiculo
{
	//classe entidade	
	private $idveiculo;
	private $tipo;
	private $capacidade;
	private $marca;

	public function __construct() {}
	public function setIdveiculo($idveiculo)
	{
		$this->idveiculo = $idveiculo;
	}
	public function getIdveiculo()
	{
		return $this->idveiculo;
	}
	//demais getters e setters

	public function getTipo()
	{
		return $this->tipo;
	}
	public function setTipo($tipo)
	{
		$this->tipo = $tipo;
	}

	public function getCapacidade()
	{
		return $this->capacidade;
	}
	public function setCapacidade($capacidade)
	{
		$this->capacidade = $capacidade;
	}

	public function getMarca()
	{
		return $this->marca;
	}
	public function setMarca($marca)
	{
		$this->marca = $marca;
	}
}
