<?php
session_start(); //Inicia a sessão
//área de memória dentro do servidor
//carrinho de compras, seus dados de conexão
//qualquer variável que vc queira criar
//include_once("visao/topo.php");
include_once("visao/cabecalho.php");
include_once("controle/ListarVeiculo_class.php");
include_once("controle/ListarUsuario_class.php")
$index = new ListarVeiculo();
//atribuição de responsabilidade
//o controle sabe como exibir a lista de veiculos
//include_once("visao/base.php");
include_once("visao/rodape.php");
